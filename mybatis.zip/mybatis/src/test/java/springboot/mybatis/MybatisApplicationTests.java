package springboot.mybatis;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import springboot.mybatis.user.dao.UserDao;
import springboot.mybatis.user.entity.User;

import java.util.List;

@SpringBootTest
class MybatisApplicationTests {
	@Autowired
	private UserDao userDao;

	@Test
	void contextLoads() {
		PageHelper.startPage(1, 2);
		List<User> userList = userDao.findAllUser();
		System.out.println(userList);
		PageInfo<User> pageInfo = new PageInfo<>(userList);
		System.out.println(pageInfo);
	}
}
