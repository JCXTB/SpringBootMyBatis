package springboot.mybatis.user.dao;

import springboot.mybatis.user.entity.User;

import java.util.List;

public interface UserDao {
    List<User> findAllUser();
}
